export const environment = {
  serverApiUrl: 'https://swap.movo.exchange:30279/pPotDpXXnz9a-YVkjyUOuA',
  hostUrl: 'swap.movo.exchange'
};
